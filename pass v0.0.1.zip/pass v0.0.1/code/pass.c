#include<stdio.h>
#include<string.h>
#include<windows.h>

typedef struct{
    char password[100];
    char pass[300];
}pass;

int main(void){
    pass pass1;
    char password[100];

    scanf("%s",password);

    FILE *fp=fopen("pass.dat","rb");
    if(fp==NULL){
        printf("ERROR");
        return 0;
    }
    fread(&pass1,sizeof(pass1),1,fp);
    fclose(fp);

    if(strcmp(password,pass1.password)==0){
        system(pass1.pass);
    }else{
        printf("NO");
    }   
}
