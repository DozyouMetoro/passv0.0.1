#include<windows.h>
#include<stdio.h>
#include<stdlib.h>

int main(void){
    char pass[300];
    gets(pass);
    system(pass);
    return 0;
}