#include<stdio.h>
#include<string.h>
#include<windows.h>
#include<unistd.h>

typedef struct{
    char password[100];
    char pass[300];
}pass;

int main(void){
    pass pass1;
    printf("password?\n");
    gets(pass1.password);
    //sleep(3);
    printf("pass?\n");
    gets(pass1.pass);

    FILE *fp=fopen("pass.dat","wb");
    if(fp==NULL){
        printf("ERROR");
        return 0;
    }
    fwrite(&pass1,sizeof(pass1),1,fp);
    fclose(fp);

    return 0;
}
